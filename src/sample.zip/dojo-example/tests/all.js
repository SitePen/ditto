define([
	'./model/SimpleTodoModel',
	'intern/node_modules/dojo/has!host-browser?./store/LocalStorage',
	'intern/node_modules/dojo/has!host-browser?./form/CheckBox'
], function () {});