dojo-example
=============

## Setup

```
npm install -g bower
npm install
bower install
```

Start a Selenium server locally and run:
```
npm test
```

### Run Tests on Sauce Labs

Requires Sauce Labs credentials. Uncomment `//tunnel: 'SauceLabsTunnel',` in `tests/intern.js`.

